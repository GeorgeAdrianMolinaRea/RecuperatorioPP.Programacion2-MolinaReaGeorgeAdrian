/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.util.Random;

/**
 *
 * @author User
 */
public abstract class Producto {
    protected Fabricante fabricante;
    protected String nombre;
    protected double precio;
    protected int calorias ;
    protected int tiempoPreparacion ;
    private static Random generadorAleatorio;
    
    static {
        generadorAleatorio = new Random();
    }
    public Producto( String nombre, double precio, Fabricante fabricante){
        this.fabricante = fabricante;
        this.nombre = nombre;
        this.precio = precio;
        this.calorias  = 0;
        this.tiempoPreparacion = 0;
    }
    public Producto(String nombre, double precio,String nombreFabricante,String ciudadFabricante, int antiguedadFabricante){
        this.fabricante = new Fabricante(nombreFabricante, ciudadFabricante, antiguedadFabricante);
        this.nombre = nombre;
        this.precio = precio;
        this.calorias  = 0;
        this.tiempoPreparacion = 0;
    }
    
    public int getCalorias() {
        if (this.calorias == 0) {
            this.calorias = Producto.generadorAleatorio.nextInt(800) + 200;
        }
        return this.calorias;
    }
    public int getTiempoPreparacion() {
        if (this.tiempoPreparacion == 0) {
            this.tiempoPreparacion = Producto.generadorAleatorio.nextInt(20) + 5;
        }
        return this.tiempoPreparacion;
    }
    private String mostrar(Producto p){
        StringBuilder sb = new StringBuilder();
        sb.append("Fabricante: ").append("\n");
        sb.append(this.fabricante);
        sb.append("Nombre: ").append(this.nombre).append("\n");
        sb.append("Precio: ").append(this.precio).append("\n");
        sb.append("Calorias: ").append(this.getCalorias()).append("\n");
        sb.append("Tiempo preparacion: ").append(this.getTiempoPreparacion()).append("\n");
        return sb.toString();
    }
    private static boolean sonIguales(Producto p1, Producto p2){
            if (p1 == null || p2 == null) {
            return false;
            }
            if (p1.getClass() == p2.getClass() ){
            return false;
            }
        return p1.nombre.equals(p2.nombre) && Fabricante.sonIguales(p1.fabricante, p2.fabricante);
    
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Producto)) {
            return false;
        }
        Producto otro = (Producto) obj;
        return sonIguales(this, otro);
    }
    public String toString(){
        return mostrar(this);
    }
}


