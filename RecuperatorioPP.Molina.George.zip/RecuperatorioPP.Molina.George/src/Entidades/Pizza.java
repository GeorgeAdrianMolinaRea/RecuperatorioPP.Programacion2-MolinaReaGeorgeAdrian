/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author User
 */
public class Pizza extends Producto implements IVendible{
    private TipoPizza sabor;
    private TamanoPizza tamano;

    public Pizza(String nombre, int precio, Fabricante f1, TipoPizza sabor, TamanoPizza tamano){
        super(nombre, precio, f1);
        this.sabor = sabor;
        this.tamano = tamano;

    }

    
    @Override
    public double getPrecioTotal() {
        double precioTotal = this.precio;
        
        switch (this.tamano) {
            case CHICA:
                precioTotal = this.precio * 1.05;
                break;
            case MEDIANA:
                precioTotal = this.precio * 1.10;
                break;
            case GRANDE:
                precioTotal = this.precio * 1.20;
                break;
        }
        
        return precioTotal;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append("\n");
        sb.append("sabor :").append(this.sabor).append("\n");
        sb.append("Tamano: ").append(this.tamano).append("\n");
        sb.append("Precio Total: ").append(this.getPrecioTotal()).append("\n");
        return sb.toString();
    }
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Pizza)) {
            return false;
        }
        Pizza otro = (Pizza) obj;
        return this.sabor == otro.sabor && this.tamano == otro.tamano;
    }
    
    
}
