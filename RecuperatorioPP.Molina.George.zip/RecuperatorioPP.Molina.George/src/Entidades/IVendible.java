
package Entidades;


public interface IVendible {
    public double getPrecioTotal();
}
