
package Entidades;

import java.util.ArrayList;
import java.util.Iterator;


public class Pizzeria implements Iterable<Producto> {
    private String nombre;
    private int capacidad;
    private ArrayList<Producto> productos ;
    
    public Pizzeria(){
        this.productos = new ArrayList<>();
        this.capacidad = 3;
    }
    public Pizzeria(String nombre, int capacidad){
        this();
        this.nombre = nombre;
        this.capacidad = capacidad;
    }
    private boolean sonIguales(Producto p){
        for (Producto producto : this.productos) {
            
            if (p.equals(producto)) {
                return true;
            }
        }
        return false;
    }
    public void agregar(Producto p){
        if (this.productos.size() >= this.capacidad) {
            System.out.println("No hay capacidad para agregar mas productos");
            return;
        }
        
        if (this.sonIguales(p)) {
            System.out.println("El producto ya se encuentra en la Pizzeria");
            return;
        }
        
        this.productos.add(p);
        System.out.println("Producto agregado exitosamente");
    }
    private double getPrecioProductos(TipoProducto tipo){    
        double total = 0.0;
        
        switch (tipo) {
            case PIZZAS:
                total = this.getPrecioPizzas();
                break;
            case POSTRES:
                total = this.getPrecioPostres();
                break;
            case TODOS:
                total = this.getPrecioTotal();
                break;
        }
        
        return total;
    }
    private double getPrecioPizzas(){
        double total = 0.0;
        
        for (Producto producto : this.productos) {
            if (producto instanceof Pizza) {
                Pizza pizza = (Pizza) producto;
                total += pizza.getPrecioTotal();
            }
        }
        
        return total;
    }
    private double getPrecioPostres(){
        double total = 0.0;
        
        for (Producto producto : this.productos) {
            if (producto instanceof Postre) {
                Postre postre = (Postre) producto;
                total += postre.getPrecioTotal();
            }
        }
        
        return total;
    }
    private double getPrecioTotal(){
        return this.getPrecioPizzas() + this.getPrecioPostres();

    }

    @Override
    public Iterator<Producto> iterator() {
        return productos.iterator();
    }
    @Override
    public String toString() {
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== Pizzeria ===\n");
        sb.append("Nombre: ").append(this.nombre).append("\n\n");
        sb.append("Cantidad de productos: ").append(this.productos.size()).append("\n\n");
        sb.append("PRODUCTOS:\n");
        sb.append("--------------------\n");
        
        for (Producto producto : this.productos) {
            sb.append(producto.toString()).append("\n");
            sb.append("--------------------\n");
        }
        
        sb.append("\nPRECIOS TOTALES:\n");
        sb.append("Pizzas: $").append(this.getPrecioProductos(TipoProducto.PIZZAS)).append("\n");
        sb.append("Postres: $").append(this.getPrecioProductos(TipoProducto.POSTRES)).append("\n");
        sb.append("TOTAL: $").append(this.getPrecioTotal());
        
        return sb.toString();
    }

}
